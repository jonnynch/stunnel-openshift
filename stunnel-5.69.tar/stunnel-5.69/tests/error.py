"""An error occured."""

if __name__ == '__main__':
    print("Wrong_connection!")
